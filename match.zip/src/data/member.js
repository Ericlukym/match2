export const sTeam = [
  {
    id:1,
    name: 'Deryl',
    hcp:	18.6
  },
  {
    id:2,
    name: 'Lawrence',
    hcp:	17.1
  },
  {
    id:3,
    name: 'Thomas',
    hcp:	23.6
  },
  {
    id:4,
    name: 'Clarence',
    hcp:	20
  },
  {
    id:5,
    name: 'Tony',
    hcp:	18.1
  },
  {
    id:6,
    name: 'SK Wan',
    hcp:	18.8
  },
  {
    id:7,
    name: 'Leo',
    hcp:	16.8
  },
  {
    id:8,
    name: 'Paul',
    hcp:	19.7
  },
  {
    id:9,
    name: 'KC Goh',
    hcp:	11.2
  },
  {
    id:10,
    name: 'Isaiah',
    hcp:	19.9
  },
  {
    id:11,
    name: 'Anna',
    hcp:	46.4
  },

]

export const hkTeam = [
  {
    id:1,
    name: 'Tomkys',
    hcp:  23
  },
  {
    id:2,
    name: 'Kenneth',
    hcp:  25
  },
  {
    id:3,
    name: 'Neil',
    hcp:  25
  },
  {
    id:4,
    name: 'Berry',
    hcp:  12
  },
  {
    id:5,
    name: 'Johnny',
    hcp:  17
  },
  {
    id:6,
    name: 'Kelvin',
    hcp:  20
  },
  {
    id:7,
    name: 'Gary',
    hcp:  25
  },
  {
    id:8,
    name: 'Henry',
    hcp:  20
  },
  {
    id:9,
    name: 'Jonathan',
    hcp:  23
  },
  {
    id:10,
    name: 'Eric',
    hcp:  25
  },
  {
    id:11,
    name: 'Thomas',
    hcp:  30
  },

]